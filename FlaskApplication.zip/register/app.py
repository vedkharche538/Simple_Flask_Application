from flask import Flask,render_template,request,flash,redirect,url_for
from flask_mysqldb import MySQL
app = Flask(__name__)
app.secret_key = 'many random bytes'

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'curd'

mysql = MySQL(app)
@app.route('/')
def register():
    return render_template('index.html')


@app.route('/login',methods=['GET','POST'])
def login():
    if request.method == "POST":
        cur = mysql.connection.cursor()
        email = request.form['email']
        password = request.form['password']
        cur.execute(
            "SELECT `password` from login where `email` = %s", (email,))
        data = cur.fetchall()
        print("data",data)
        # mysql.connection.commit()
        if data[0][0] == password:
            return redirect(url_for('profile',email= email))
        else:
            flash("Incorrect Username or Password! Please check and try again.")
            return redirect(url_for('login'))
    else:
        flash('Log out Successfully')
        return render_template('log.html')


@app.route('/data',methods=['GET','POST'])
def data():
    if request.method =='POST':
        firstname = request.form['f_name']
        lastname = request.form['l_name']
        email = request.form['email']
        password = request.form['password']
        country = request.form['country']
        gender = request.form['gender']
        job = request.form['job']
        phone = request.form['phone']
        address = ""
        username = firstname + " "+lastname

        mysql.connection.commit()
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO login (username,password, email,address, phone, gender,jobspec,education) VALUES (%s, %s, %s, %s,%s,%s,%s,%s)",
                    (username, password, email, address, phone, gender, job, country))
        mysql.connection.commit()
    return redirect(url_for('login'))

@app.route('/profile/<email>')
def profile(email):
    if email:
        cur = mysql.connection.cursor()
        cur.execute("Select * from login where email = %s", (email,))
        data = cur.fetchall()
        print(data)
        cur.close()
        flash('')
        return render_template('profile1.html', students=data)
    else:
        return redirect(url_for('login'))

@app.route('/update',methods=['GET','POST'])
def update():
    if request.method =='POST':
        username = request.form['username']
        email = request.form['email']
        address = request.form['address']
        phone = request.form['phone']
        job = request.form['job']
        education = request.form['education']
        cur = mysql.connection.cursor()
        cur.execute("UPDATE login SET phone=%s, address=%s, jobspec=%s, education=%s WHERE email=%s ",
                    (phone, address, job, education, email))
        flash("Data Updated Successfully")
        mysql.connection.commit()
        return redirect(url_for('profile',email=email))
    else:
        flash('You Logged out!!')
        return redirect(url_for('login'))


if __name__ == '__main__':
    app.run(debug = True)
