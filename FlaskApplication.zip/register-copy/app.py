try:
    from flask import Flask, render_template, request, flash, redirect, url_for, session
    from flask_mysqldb import MySQL
    from authlib.integrations.flask_client import OAuth
    import json
    from datetime import timedelta
    from functools import wraps
except Exception as e:
    print("Some Module are Missing : {}".format(e))

app = Flask(__name__)
app.secret_key = 'many random bytes'

global client_id
global client_secret

client_id = "127388640287-otcmfs9b866po2opr8kps82lsdfccs2q.apps.googleusercontent.com"
client_secret = "dHQ-PpSge2_QhiF8bRWjLIcR"

# Session config
app.secret_key = "mysecretkey"
app.config['SESSION_COOKIE_NAME'] = 'google-login-session'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes = 5)

# oAuth Setup
oauth = OAuth(app)
google = oauth.register(
    name = 'google',
    client_id = client_id,
    client_secret = client_secret,
    access_token_url = 'https://accounts.google.com/o/oauth2/token',
    access_token_params = None,
    authorize_url = 'https://accounts.google.com/o/oauth2/auth',
    authorize_params = None,
    api_base_url = 'https://www.googleapis.com/oauth2/v1/',
    userinfo_endpoint = 'https://openidconnect.googleapis.com/v1/userinfo',
    # This is only needed if using openId to fetch user info
    client_kwargs = {'scope': 'openid email profile'},
)


def isLoggedIN():
    try:
        user = dict(session).get('profile', None)
        if user:
            return user.get("name", None), user.get("email", None)
        else:
            return None, None
    except Exception as e:
        return e


# Wrapper Definition


def login_required(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        if 'logged_in' in session:
            return f(*args, **kwargs)
        else:
            flash("You need to login first")
            return redirect('/login')

    return wrap


app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'curd'

mysql = MySQL(app)


@app.route('/google/login')
def google_login():
    google = oauth.create_client('google')  # create the google oauth client
    redirect_uri = url_for('google_authorize', _external = True)
    return google.authorize_redirect(redirect_uri)


@app.route('/google/authorize')
def google_authorize():
    google = oauth.create_client('google')  # create the google oauth client
    token = google.authorize_access_token()  # Access token from google (needed to get user info)
    resp = google.get('userinfo')  # userinfo contains stuff u specificed in the scrope
    user_info = resp.json()
    user = oauth.google.userinfo()  # uses openid endpoint to fetch user info
    print(user_info)
    session['profile'] = user_info
    session['logged_in'] = True
    session.permanent = False  # make the session permanant so it keeps existing after broweser gets closed
    return redirect('/register')


@app.route('/logout', methods = ['POST', 'GET'])
@login_required
def logout():
    for key in list(session.keys()):
        session.pop(key)
    flash("You have been logged out!")
    return redirect('/')


@app.errorhandler(405)
def method_not(error):
    return render_template('405.html', exception = error)


@app.errorhandler(404)
def page_not_found(error):
    return render_template('404.html', exception = error)


@app.errorhandler(500)
def internal_server(error):
    return render_template('500.html', exception = error)


@app.route('/register')
def register():
    f_name = ''
    l_name = ''
    user, email = isLoggedIN()
    if user is not None:
        f_name, l_name = user.split(' ')
    return render_template('index.html', firstname = f_name, lastname = l_name, email = email)


@app.route('/', methods = ['GET', 'POST'])
@app.route('/<path:url_path>', methods = ['GET', 'POST'])
@app.route('/login', methods = ['GET', 'POST'])
def login(url_path = '/'):
    if request.method == "POST":
        try:
            cur = mysql.connection.cursor()
            email = request.form['email']
            password = request.form['password']
            cur.execute(
                "SELECT `password` from login where `email` = %s", (email,))
            data = cur.fetchall()
            # print("data", data)
            if data[0][0] == password:
                # mysql.connection.commit()
                session['logged_in'] = True
                return redirect(url_for('home', email = email))
            else:
                flash("Incorrect credentials! Please check and try again.")
                return redirect(url_for('login'))
        except Exception as e:
            return render_template('500.html', exception=e)
    else:
        return render_template('log.html')


@app.route('/data', methods = ['GET', 'POST'])
def data():
    if request.method == 'POST':
        try:
            firstname = request.form['f_name']
            lastname = request.form['l_name']
            email = request.form['email']
            password = request.form['password']
            education = request.form['country']
            gender = request.form['gender']
            job = request.form['job']
            phone = request.form['phone']
            address = request.form['address']
            username = firstname + " " + lastname
            session['logged_in'] = True
            print(education, job, username)
            mysql.connection.commit()
            cur = mysql.connection.cursor()
            cur.execute(
                "INSERT INTO login (username,password,address,email,gender,jobspec,phone,education) VALUES (%s,%s, %s, %s,%s,%s,%s,%s)",
                (username, password, address, email, gender, job, phone, education))
            mysql.connection.commit()
            flash('Registered Successfully! Now login in with credentials!')
            return redirect(url_for('login'))
        except Exception as e:
            render_template('500.html', exception=e)
    else:
        flash('Try to Login Again!!')
        return redirect(url_for('login'))


@app.route('/profile/<email>')
@login_required
def profile(email):
    if email:
        try:
            cur = mysql.connection.cursor()
            cur.execute("Select * from login where email = %s", (email,))
            data = cur.fetchall()
            print(data)
            cur.close()
            flash('')
            return render_template('profile1.html', students = data)
        except Exception as e:
            flash("You Encounter With An DataProcessing Error")
            redirect(url_for('login'))
    else:
        return redirect(url_for('login'))


@app.route('/update', methods = ['GET', 'POST'])
@login_required
def update():
    if request.method == 'POST':
        try:
            username = request.form['username']
            email = request.form['email']
            address = request.form['address']
            phone = request.form['phone']
            job = request.form['job']
            education = request.form['education']
            cur = mysql.connection.cursor()
            cur.execute("UPDATE login SET phone=%s, address=%s, jobspec=%s, education=%s WHERE email=%s ",
                        (phone, address, job, education, email))
            flash("Data Updated Successfully")
            mysql.connection.commit()
            return redirect(url_for('profile', email = email))
        except Exception as e:
            flash("You Encounter With An DataProcessing Error")
            redirect(url_for('login'))
    else:
        flash('You Logged out!!')
        return redirect(url_for('login'))


@app.route('/home/<email>', methods = ['GET', 'POST'])
@login_required
def home(email):
    log_in = session.get('logged_in', None)
    if email is None or email == '' and log_in is None:
        flash('Credentials Not Matched! Please try again!!')
        return redirect(url_for('login'))
    else:
        return render_template('home.html', email = email)


if __name__ == '__main__':
    app.run(debug = True)
